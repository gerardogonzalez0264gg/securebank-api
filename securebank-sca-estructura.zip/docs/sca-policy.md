# Política SCA de SecureBank API

## Umbral

| CVSS | Acción | Responsable |
|---|---|---|
| >= 6.0 | **Bloqueo**: el build falla | Equipo de desarrollo (parche antes de continuar) |
| < 6.0 | **Registrar**: continúa y va al backlog (plazo 30 días) | Backlog de deuda técnica |

## Justificación

SecureBank maneja datos de clientes, saldos y tokens JWT (activos del
`threat-model.md`). Se baja el umbral de la clase (9.0 / 7.0) a 6.0 porque
un fallo en una dependencia puede exponer esos activos.

No se baja a 5.0 o menos: bloquear en exceso rompe el pipeline a diario y
fomenta el bypass (debate de la Sesión 6).

## Excepciones

Solo con aprobación del Security Champion, motivo escrito y fecha de
vencimiento. Sin vencimiento no hay excepción.

## Implementación

`scripts/cvss_gate.py` lee el JSON de Trivy y termina con código 1 si algún
hallazgo alcanza el umbral. Trivy filtra por categoría (LOW/MEDIUM/HIGH/CRITICAL)
y no por número, por eso el corte exacto en 6.0 se hace en el script.
