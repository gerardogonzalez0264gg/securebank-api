# SecureBank API

Proyecto académico de DevSecOps.

## Descripción

SecureBank API es una API bancaria simulada utilizada
para estudiar arquitectura, seguridad y automatización
CI/CD.

## Arquitectura

El proyecto se divide en:

- src: código fuente
- tests: pruebas
- docs: documentación y threat modeling
- .github: automatización y reglas del repositorio


## Configuración de repositorio

Este proyecto sigue un flujo de trabajo basado en ramas protegidas, con integración continua vía Pull Requests.

### Estrategia de ramas

- **`main`**: rama de producción. Contiene únicamente código estable y liberado. Cada commit en `main` representa una versión publicable.
- **`develop`**: rama de integración. Las features terminadas se mezclan acá antes de pasar a `main`.
- **`feature/*`**: ramas de desarrollo de nuevas funcionalidades, creadas desde `develop` (ej. `feature/auth-mfa`, `feature/transfer-limits`).
- **`hotfix/*`**: ramas para correcciones urgentes de seguridad o bugs críticos, creadas directamente desde `main` cuando no se puede esperar al ciclo normal (ej. `hotfix/cve-2026-0012`).

### Flujo de trabajo

![Diagrama de flujo de Git](img/Flujo.png)

1. Se crea una rama `feature/*` desde `develop` para cada nueva funcionalidad.
2. Al finalizar, se abre un **Pull Request** hacia `develop` para su revisión e integración.
3. Cuando `develop` acumula suficientes cambios estables, se abre un PR de `develop` hacia `main`.
4. Los releases publicables se marcan con un **tag** de versión (ej. `v1.2.0`) sobre `main`.
5. Ante una vulnerabilidad o bug urgente, se crea una rama `hotfix/*` directo desde `main`, se corrige y se mergea de vuelta a `main` (y luego se sincroniza con `develop`).

> ⚠️ **Regla de oro:** toda entrada a `main` pasa por Pull Request revisado. Sin excepciones.

## § 2 · Roles y responsabilidades
 
| Rol | Responsabilidad |
|---|---|
| **Developer** | Desarrolla en ramas `feature/*`, abre Pull Requests, no puede mergear su propio código a `develop` ni a `main`. |
| **Reviewer** | Aprueba PRs dentro de su equipo. Verifica calidad, estándares y que no haya secretos expuestos. |
| **Code Owner** | Dueño técnico de una ruta o módulo (definido en `CODEOWNERS`). Su aprobación es obligatoria para cambios en su área, incluidos `.github/workflows/`. |
| **Release Manager** | Único rol habilitado para crear tags/releases sobre `main`. Verifica checklist de aprobación previa. |
| **Secret Custodian** | Los 2 revisores externos con acceso a secretos productivos. Gestionan rotación y auditoría de accesos. |

## § 3 · Clase 6 — SCA, dependencias, CVE y SBOM

**Problema que resuelve:** SAST (Semgrep) solo revisa el código que escribimos, pero la mayor parte de una app moderna viene de librerías de terceros. En un banco, una dependencia vulnerable puede exponer saldos, cuentas o tokens JWT. SCA analiza esas dependencias y las cruza con bases públicas de vulnerabilidades.

### Qué parte del repositorio aplica la clase

| Parte del repo | Concepto de la clase | Qué soluciona |
|---|---|---|
| `requirements.txt` | Dependencias directas y transitivas, versión vulnerable | Deja un inventario con versiones fijas: el escaneo es reproducible y siempre analiza lo mismo. Las versiones son antiguas **a propósito** (API deliberadamente vulnerable). |
| `.github/workflows/ci.yml` (job `sca`) | Pipeline SAST → **SCA** → **SBOM** → Build, con Trivy | Automatiza el análisis en cada push y PR; nadie depende de ejecutarlo a mano. |
| `scripts/cvss_gate.py` | Política de umbrales CVSS (semáforo) | Decide solo si el pipeline pasa o falla, leyendo el CVSS de cada hallazgo. |
| `docs/sca-policy.md` | Debate seguridad vs. velocidad | Documenta por qué el umbral es 6.0 y cómo se manejan las excepciones (trazabilidad). |
| `reports/` | Entregables 01 (SBOM) y 02 (reporte de vulnerabilidades) | Guarda la evidencia que sale del pipeline. |

### CVE, CWE y CVSS en este proyecto

- **CVE** (el qué): identifica la vulnerabilidad concreta, por ejemplo `CVE-2023-30861` en Flask.
- **CWE** (el por qué): clasifica el tipo de debilidad, por ejemplo `CWE-200` (exposición de información).
- **CVSS** (el cuánto): puntaje de 0.0 a 10.0 que gobierna la política.

### Política de umbrales

Por ser una API bancaria, el bloqueo es más estricto que el de la clase:

| CVSS | Acción |
|---|---|
| **≥ 6.0** | **Bloqueado**: el build falla y se debe parchar |
| **< 6.0** | **Registrar**: continúa y va al backlog |

### Cómo ejecutarlo localmente

```bash
trivy fs --format cyclonedx --output reports/securebank-sbom.cdx.json .
trivy fs --scanners vuln --format json --output reports/securebank-vulns.json .
python3 scripts/cvss_gate.py reports/securebank-vulns.json 6.0
```

### Estado de los entregables

La estructura está lista. Los archivos de `reports/` los genera el CI en su primera ejecución (ver `reports/README.md`).
 
---
