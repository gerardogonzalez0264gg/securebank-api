# reports/

Artefactos de la Sesión 6 (SCA). **Los genera el pipeline, no se escriben a mano.**

| Archivo | Entregable | Lo produce |
|---|---|---|
| `securebank-sbom.cdx.json` | 01 · SBOM (CycloneDX) | Trivy, job `sca` |
| `securebank-vulns.json` | 02 · salida JSON de la herramienta | Trivy, job `sca` |
| `securebank-vulns.html` | 02 · reporte legible con decisión por CVE | `scripts/cvss_gate.py` |

Tras la primera ejecución del CI, descarga el artefacto `reportes-sca` desde la
pestaña Actions y súbelo a esta carpeta.
