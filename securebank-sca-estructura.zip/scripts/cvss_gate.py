#!/usr/bin/env python3
"""Compuerta de política CVSS para SecurePipeline.

Lee el JSON que genera Trivy, clasifica cada vulnerabilidad según el umbral
CVSS y decide si el pipeline pasa o falla.

Uso:
    python scripts/cvss_gate.py reports/securebank-vulns.json [umbral] [salida.html]

Política (ver docs/sca-policy.md):
    CVSS >= umbral  -> BLOQUEO  (el script termina con código 1 y el CI falla)
    CVSS <  umbral  -> REGISTRAR (el pipeline continúa; va al backlog)
"""
import html
import json
import sys
from pathlib import Path

UMBRAL_POR_DEFECTO = 6.0

# Si una vulnerabilidad no trae puntaje numérico, usamos el piso de su categoría.
# Es la opción conservadora: en un banco preferimos bloquear de más que de menos.
PISO_POR_SEVERIDAD = {"CRITICAL": 9.0, "HIGH": 7.0, "MEDIUM": 4.0, "LOW": 0.1}


def mejor_cvss(vuln):
    """Devuelve el puntaje CVSS v3 de la vulnerabilidad (prefiere la fuente NVD)."""
    cvss = vuln.get("CVSS") or {}
    for fuente in ["nvd", *cvss.keys()]:
        puntaje = (cvss.get(fuente) or {}).get("V3Score")
        if puntaje is not None:
            return float(puntaje)
    return PISO_POR_SEVERIDAD.get(str(vuln.get("Severity", "")).upper(), 0.0)


def extraer_hallazgos(reporte):
    """Aplana el JSON de Trivy: Results -> Vulnerabilities -> una fila por CVE."""
    filas = []
    for resultado in reporte.get("Results") or []:
        for v in resultado.get("Vulnerabilities") or []:
            filas.append(
                {
                    "cve": v.get("VulnerabilityID", "?"),
                    "paquete": v.get("PkgName", "?"),
                    "version": v.get("InstalledVersion", "?"),
                    "corregida": v.get("FixedVersion") or "sin parche",
                    "cwe": ", ".join(v.get("CweIDs") or []) or "n/d",
                    "cvss": mejor_cvss(v),
                }
            )
    return sorted(filas, key=lambda f: f["cvss"], reverse=True)


def escribir_html(filas, umbral, ruta):
    """Genera el reporte legible que pide el entregable 02."""
    cuerpo = "".join(
        "<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td>"
        "<td>{:.1f}</td><td><b>{}</b></td></tr>".format(
            *(html.escape(str(x)) for x in (
                f["cve"], f["paquete"], f["version"], f["corregida"], f["cwe"]
            )),
            f["cvss"],
            "BLOQUEO" if f["cvss"] >= umbral else "REGISTRAR",
        )
        for f in filas
    )
    Path(ruta).write_text(
        "<!doctype html><meta charset='utf-8'><title>SecureBank - Vulnerabilidades</title>"
        "<h1>SecureBank API - Componentes vulnerables</h1>"
        f"<p>Umbral de bloqueo: CVSS &ge; {umbral}</p>"
        "<table border='1' cellpadding='6'><tr><th>CVE</th><th>Componente</th>"
        "<th>Versi&oacute;n</th><th>Corregida</th><th>CWE</th><th>CVSS</th>"
        f"<th>Decisi&oacute;n</th></tr>{cuerpo}</table>",
        encoding="utf-8",
    )


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    ruta_json = Path(sys.argv[1])
    umbral = float(sys.argv[2]) if len(sys.argv) > 2 else UMBRAL_POR_DEFECTO
    ruta_html = sys.argv[3] if len(sys.argv) > 3 else "reports/securebank-vulns.html"

    filas = extraer_hallazgos(json.loads(ruta_json.read_text(encoding="utf-8")))
    bloqueos = [f for f in filas if f["cvss"] >= umbral]

    Path(ruta_html).parent.mkdir(parents=True, exist_ok=True)
    escribir_html(filas, umbral, ruta_html)

    for f in filas:
        marca = "BLOQUEO  " if f["cvss"] >= umbral else "registrar"
        print(f"[{marca}] {f['cvss']:>4.1f}  {f['cve']}  {f['paquete']} {f['version']}  ({f['cwe']})")
    print(f"\nTotal: {len(filas)} hallazgos, {len(bloqueos)} bloquean (umbral CVSS >= {umbral})")

    return 1 if bloqueos else 0


if __name__ == "__main__":
    sys.exit(main())
